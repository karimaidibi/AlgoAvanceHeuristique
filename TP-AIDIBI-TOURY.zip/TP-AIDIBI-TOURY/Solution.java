
import java.util.ArrayList;


public class Solution extends ArrayList<Coord> {
    
    public Solution(Coord c){
        this.add(c);
    }
    public Solution(){

    }

    public void addCoord(Coord c){
        this.add(c);
    }


}
