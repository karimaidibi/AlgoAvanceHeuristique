public interface IFactory{
    //utile pour le départ du HillClimbing, dans lequel on veut partir d'un élément au hasard
    IElemHC getRandomSol();
}
